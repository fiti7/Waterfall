#         {
#             var gantt1 = new RGraph.Gantt('cvs', [
#                                                   [31, 28, 67, 'Richard'], [0, 28, 50, 'Rachel'], [12, 28, 45, 'Fred'],
#                                                   [59, 14, 0, 'Barney'],   [59, 21, 5, 'Gloria'], [46, 31, 92, 'Paul'],
#                                                   [80, 21, 46, 'Harry'],   [94, 17, 84, 'Shane'], [34, 14, 32, 'Kyle'],
#                                                   [64, 14, 28, 'Cynthia'], [13, 61, 74, 'Mabel'], [84, 31, 16, 'Paul'],
#                                                   [80, 22, 45, 'Kiffen'], [0, 115, 50, 'John']
#                                                  ])
#                 .Set('xmax', 122)
#                 .Set('labels', ['January', 'February', 'March', 'April'])
#                 .Draw();
#         }

import ExtractData
import pprint

elements = ["START_MSEC", "FIRST_PACKET_DELTA", "CONNECT_DELTA", "OBJECT_TEXT"]

data = ExtractData.main()

#first packet + connect , fpc - c / fpc


myarray = []
#we want this in the form [[start, middle, end, label]...]

#if it is a viable item (has an object text? )
#pull out start time, connect delta, first packet

#start with an array of entries
for datum in data:
   # print(datum)
    newarray = [0] * 4
    #now each element is its own array in that array
    datum = datum.split(" ")
    #print(datum)
    #now we have a tuple in each of those array of element : value 
    #example - [[[Header_byte,"510"],[element_delta,"3042]...]...]
    for item in datum:
        item = item.split("=")
        #print(item)
        n=0
        #now check and see if it matches
        while n < 4:
            if item[0] == elements[n]:
                newarray[n] = (item[1].strip("\'").strip("\"")) 
            n+=1
    
    if newarray[3] != 0:
        myarray.append(newarray)


for item in myarray:
     temp = int(item[2])
     item[1] = int(item[1]) + temp
     if temp != 0:
         item[2] = 100 * temp/int(item[1])
     item[0] = int(item[0])
     
pprint.pprint(myarray)
print (".Set('xmax',",myarray[-1][0] + myarray[-1][1], ")" )